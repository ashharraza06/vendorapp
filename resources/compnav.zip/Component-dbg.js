sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("compnav.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);